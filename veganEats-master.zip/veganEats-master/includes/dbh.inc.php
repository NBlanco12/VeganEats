<?php

$dbServername = "localhost";
$dbUsername = "phpmyadmin";
$dbPassword = "VeganOcean2k19";
$dbName = "loginsystem";

$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);
