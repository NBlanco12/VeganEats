# veganEats
Our senior project 2019.
Here you will find all of the files that make up the Vegan Eats website. 

IP Address: http://68.183.98.184/

Learn Git
https://www.youtube.com/watch?v=Y9XZQO1n_7c
